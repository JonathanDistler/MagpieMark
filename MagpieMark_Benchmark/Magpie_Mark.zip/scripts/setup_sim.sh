#!/usr/bin/env bash
# Install project Python additions after installing native prerequisites.
set -eo pipefail
project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project"
test -r /opt/ros/jazzy/setup.bash || {
    echo 'Install the Ubuntu prerequisites in README_SIMULATION.md first.' >&2
    exit 1
}
if [[ ! -e .venv/pyvenv.cfg ]]; then
    /usr/bin/python3 -m venv --system-site-packages .venv
fi
.venv/bin/python -m pip install -r requirements-venv.txt
