#!/usr/bin/env bash
# Use from an extracted source tree or clean checkout in a system ROS terminal.
set -eo pipefail
project="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project"
source /opt/ros/jazzy/setup.bash
env_check_python=/usr/bin/python3
if [[ -x .venv/bin/python ]]; then
    env_check_python=.venv/bin/python
fi
colcon --log-base log-system build --build-base build-system --install-base install-system \
    --paths px4_msgs ros2/swarm_mavsdk_ros2 ros2/drone_swarm_controller_ros2 \
    --symlink-install --cmake-args -DPython3_EXECUTABLE=/usr/bin/python3 -DPYTHON_EXECUTABLE=/usr/bin/python3
source install-system/local_setup.bash
ROS_DOMAIN_ID=94 "$env_check_python" -m pytest -q ros2/swarm_mavsdk_ros2/test
/usr/bin/python3 scripts/verify_px4_contract.py
