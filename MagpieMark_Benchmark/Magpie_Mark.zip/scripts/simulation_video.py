"""Record the Gazebo overview camera and overlay measured model trails."""

from collections import deque
import colorsys
import math
from pathlib import Path
import select
import subprocess
import sys
import threading
import time
import uuid
from xml.etree import ElementTree as ET


COLORS = ((255, 216, 91), (234, 126, 255), (88, 181, 255))  # BGR: cyan, magenta, amber
FPS = 15
FOV = 1.05
TRAIL_POINTS = 160


class SimulationVideo:
    def __init__(self, world, directory, environment, world_kind, count, spacing,
                 *, model_prefix, physics_step=None, close_view=False):
        run_id = uuid.uuid4().hex
        self.path = directory / f"flight-{run_id}.mp4"
        self.partial = directory / f".flight-{run_id}.partial.mp4"
        self.world = directory / f"video-world-{run_id}.sdf"
        self.environment = environment
        self.topic = f"/flight_video_{run_id}/image"
        self.model_prefix = model_prefix
        self.count = count
        self.process = None
        self.started = False

        tree = ET.parse(world)
        if physics_step is not None:
            tree.find("world/physics/max_step_size").text = str(physics_step)
        x = 4.0 if world_kind == "obstacles" else 0.0
        y = -2.0 if world_kind == "obstacles" else (count - 1) * spacing / 2
        distance = max(12.0 if world_kind != "obstacles" else 22.0, y * 2.6)
        pitch = 0.65
        if close_view:
            distance, pitch = max(8.5, y * 2.6), .74
        model = ET.fromstring(f"""
          <model name="flight_video_camera">
            <static>true</static>
            <pose>{x - distance * math.cos(pitch)} {y}
                  {1.5 + distance * math.sin(pitch)} 0 {pitch} 0</pose>
            <link name="camera_link">
              <sensor name="camera" type="camera">
                <always_on>true</always_on>
                <update_rate>{FPS}</update_rate>
                <topic>{self.topic}</topic>
                <camera>
                  <horizontal_fov>{FOV}</horizontal_fov>
                  <image><width>640</width><height>360</height></image>
                  <clip><near>0.1</near><far>{distance * 3}</far></clip>
                </camera>
              </sensor>
            </link>
          </model>""")
        tree.find("world").append(model)
        tree.write(self.world, encoding="utf-8", xml_declaration=True)

    def start(self, processes):
        self.process = processes.start(
            "flight-video", ["/usr/bin/python3", str(Path(__file__).resolve()),
                             str(self.world), str(self.partial), str(self.path),
                             self.model_prefix, str(self.count)],
            self.environment, stdin=subprocess.PIPE,
        )
        processes.wait_for(lambda: self.partial.is_file() and self.partial.stat().st_size > 0,
                           "Gazebo camera recording (see flight-video.log)", timeout=60)
        self.started = True
        print(f"Recording video to {self.path}", flush=True)

    def stop(self):
        if self.process is not None:
            self.process.stdin.close()
            returncode = self.process.wait(timeout=20)
            if self.started and (returncode != 0 or not self.path.is_file()):
                raise RuntimeError(f"Could not finalize video {self.path}; inspect flight-video.log.")
            if self.path.is_file():
                print(f"Video saved: {self.path}", flush=True)


def drone_color(drone_id):
    if drone_id < len(COLORS):
        return COLORS[drone_id]
    rgb = colorsys.hsv_to_rgb(drone_id * .61803398875 % 1., .72, 1.)
    return tuple(round(channel * 255) for channel in reversed(rgb))


def project(point, camera, pitch, width, height):
    x, y, z = (point[axis] - camera[axis] for axis in range(3))
    cos_pitch, sin_pitch = math.cos(pitch), math.sin(pitch)
    depth = x * cos_pitch - z * sin_pitch
    if depth <= .1 or not all(math.isfinite(value) for value in (x, y, z)):
        return None
    focal = width / (2 * math.tan(FOV / 2))
    return (round(width / 2 - focal * y / depth),
            round(height / 2 - focal * (x * sin_pitch + z * cos_pitch) / depth))


def draw_trails(image, measured, trails, colors, camera, pitch, cv2, np):
    height, width = image.shape[:2]
    for drone_id, point in measured.items():
        path = trails[drone_id]
        pixel = project(point, camera, pitch, width, height)
        if pixel is None:
            path.clear()
            continue
        if not path or math.dist(pixel, path[-1]) >= 2:
            path.append(pixel)
        color = colors[drone_id]
        if len(path) > 1:
            line = np.asarray(path, dtype=np.int32)
            cv2.polylines(image, [line], False, (18, 18, 18), 4, cv2.LINE_AA)
            cv2.polylines(image, [line], False, color, 2, cv2.LINE_AA)
        cv2.circle(image, pixel, 5, color, 2, cv2.LINE_AA)
        cv2.putText(image, str(drone_id), (pixel[0] + 7, pixel[1] - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, .4, color, 1, cv2.LINE_AA)


def capture(world_file, partial, destination, model_prefix, count):
    import cv2
    import numpy as np
    from gz.msgs10.image_pb2 import Image, PixelFormatType
    from gz.msgs10.pose_v_pb2 import Pose_V
    from gz.transport13 import Node

    cv2.setNumThreads(1)
    world = ET.parse(world_file).find("world")
    camera_model = world.find("model[@name='flight_video_camera']")
    x, y, z, _, pitch, _ = map(float, camera_model.findtext("pose").split())
    camera = (x, y, z)
    topic = camera_model.findtext("link/sensor/topic")
    pose_topic = f"/world/{world.get('name')}/pose/info"
    model_ids = {f"{model_prefix}_{i}": i for i in range(count)}
    colors = [drone_color(i) for i in range(count)]
    trails = [deque(maxlen=TRAIL_POINTS) for _ in range(count)]
    positions = {}
    lock = threading.Lock()
    frame = None
    last_image = None

    def on_pose(message):
        updates = {model_ids[pose.name]: (pose.position.x, pose.position.y, pose.position.z)
                   for pose in message.pose if pose.name in model_ids}
        with lock:
            positions.update(updates)

    def on_frame(message):
        nonlocal frame
        if message.pixel_format_type != PixelFormatType.Value("RGB_INT8"):
            return
        rgb = np.frombuffer(message.data, np.uint8).reshape(message.height, message.step)
        rgb = rgb[:, :message.width * 3].reshape(message.height, message.width, 3)
        bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
        with lock:
            frame = (bgr, positions.copy())

    node = Node()
    if not node.subscribe(Pose_V, pose_topic, on_pose) or not node.subscribe(Image, topic, on_frame):
        raise RuntimeError("Could not subscribe to Gazebo camera and model poses.")

    writer = None
    next_frame = time.monotonic()
    annotated = None
    try:
        # Repeat the most recent camera frame when simulation advances more slowly
        # than wall time, so playback still spans the whole launcher session.
        while not select.select([sys.stdin], [], [], max(0., next_frame-time.monotonic()))[0]:
            next_frame += 1 / FPS
            with lock:
                image = frame
            if image is None:
                continue
            if image is not last_image:
                last_image = image
                bgr, measured = image
                height, width = bgr.shape[:2]
                annotated = bgr.copy()
                draw_trails(annotated, measured, trails, colors, camera, pitch, cv2, np)
                if writer is None:
                    writer = cv2.VideoWriter(partial, cv2.VideoWriter_fourcc(*"mp4v"), FPS,
                                             (width, height))
                    if not writer.isOpened():
                        raise RuntimeError("OpenCV could not open the MP4 writer.")
            writer.write(annotated)
    finally:
        if writer is not None:
            writer.release()
        node.unsubscribe(topic)
        node.unsubscribe(pose_topic)
    if writer is None:
        raise RuntimeError("Gazebo did not supply any camera frames.")
    Path(partial).replace(destination)


if __name__ == "__main__":
    world_file, partial, destination, model_prefix, count = sys.argv[1:]
    capture(world_file, partial, destination, model_prefix, int(count))
