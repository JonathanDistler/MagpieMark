"""Record a fixed overview camera using Gazebo Harmonic's video service."""

import json
import math
import subprocess
import time
import uuid
from xml.etree import ElementTree as ET


class SimulationVideo:
    def __init__(self, world, directory, environment, world_kind, count, spacing,
                 *, physics_step=None):
        run_id = uuid.uuid4().hex
        self.path = directory / f"flight-{run_id}.mp4"
        self.world = directory / f"video-world-{run_id}.sdf"
        self.environment = environment
        self.service = f"/flight_video_{run_id}/record_video"
        self.started = False

        tree = ET.parse(world)
        if physics_step is not None:
            tree.find("world/physics/max_step_size").text = str(physics_step)
        # Look down toward the center of the course from an oblique angle.
        x = 4.0 if world_kind == "obstacles" else 0.0
        y = -2.0 if world_kind == "obstacles" else (count - 1) * spacing / 2
        distance = max(12.0 if world_kind != "obstacles" else 22.0, y * 2.6)
        pitch = 0.65
        model = ET.fromstring(f"""
          <model name="flight_video_camera">
            <static>true</static>
            <pose>{x - distance * math.cos(pitch)} {y}
                  {1.5 + distance * math.sin(pitch)} 0 {pitch} 0</pose>
            <link name="camera_link">
              <sensor name="camera" type="camera">
                <always_on>true</always_on>
                <update_rate>15</update_rate>
                <topic>{self.service.rsplit('/', 1)[0]}/image</topic>
                <camera>
                  <horizontal_fov>1.05</horizontal_fov>
                  <image><width>640</width><height>360</height></image>
                  <clip><near>0.1</near><far>{distance * 3}</far></clip>
                </camera>
                <plugin filename="gz-sim-camera-video-recorder-system"
                        name="gz::sim::systems::CameraVideoRecorder">
                  <service>{self.service}</service>
                </plugin>
              </sensor>
            </link>
          </model>""")
        tree.find("world").append(model)
        tree.write(self.world, encoding="utf-8", xml_declaration=True)

    def request(self, payload):
        result = subprocess.run(
            ["gz", "service", "-s", self.service, "--reqtype", "gz.msgs.VideoRecord",
             "--reptype", "gz.msgs.Boolean", "--timeout", "1500", "--req", payload],
            env=self.environment, capture_output=True, text=True, timeout=5,
        )
        return result.returncode == 0 and result.stdout.strip() == "data: true"

    def start(self, processes):
        payload = f'start: true, format: "mp4", save_filename: {json.dumps(str(self.path))}'
        processes.wait_for(lambda: self.request(payload), "Gazebo camera recording", timeout=45)
        self.started = True
        print(f"Recording video to {self.path}", flush=True)

    def stop(self):
        if self.started:
            self.request("stop: true")
            # Gazebo acknowledges the request before encoding finishes and the
            # temporary video is moved to its final path.
            deadline = time.monotonic() + 10
            while time.monotonic() < deadline:
                if self.path.is_file() and self.path.stat().st_size:
                    print(f"Video saved: {self.path}", flush=True)
                    return
                time.sleep(.1)
            raise RuntimeError(f"Gazebo could not finalize video: {self.path}")
