#!/usr/bin/env python3
"""Create a flat source ZIP and a SHA-256 manifest for the simulation release."""
import argparse
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SOURCES = (
    ".dockerignore", ".gitignore", "CAD", "ReadMe.md", "README_SIMULATION.md",
    "compose.jetson.yaml", "config", "deploy", "docs", "drone_test_swarms.py",
    "drone_tests.py", "drone_tests_swarms.py", "environment-locks",
    "environment.yml", "models", "px4_msgs", "requirements-venv.txt",
    "ros2/drone_swarm_controller_ros2", "ros2/swarm_mavsdk_ros2",
    "run_drone_swarm.bash", "scripts", "worlds",
)
EXCLUDED = {".git", ".github", ".venv", ".aws", ".agents", ".codex", "__pycache__",
            ".pytest_cache", "results", "test_results", "build", "install", "log"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("zipfile", type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    args = parser.parse_args()
    files = []
    for name in SOURCES:
        source = ROOT / name
        if not source.exists():
            raise FileNotFoundError(source)
        for path in sorted(source.rglob("*")) if source.is_dir() else [source]:
            relative = path.relative_to(ROOT)
            if any(part in EXCLUDED or part.endswith(".egg-info") for part in relative.parts):
                continue
            if (path.name.startswith(("mav.", ".env")) or path.name.endswith(
                    (".local.json", ".log", ".pyc", ".backup", ".tlog", ".ulg", ".mp4"))):
                continue
            if path.is_symlink():
                raise ValueError(f"Unexpected symlink: {relative}")
            if path.is_file():
                files.append(relative)
    with zipfile.ZipFile(args.zipfile, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for relative in sorted(files):
            archive.write(ROOT / relative, relative.as_posix())
    with args.manifest.open("x") as manifest, zipfile.ZipFile(args.zipfile) as archive:
        for name in archive.namelist():
            manifest.write(f"{hashlib.sha256(archive.read(name)).hexdigest()}  {name}\n")
    print(f"{args.zipfile}: {len(files)} files, {args.zipfile.stat().st_size:,} bytes")


if __name__ == "__main__":
    main()
