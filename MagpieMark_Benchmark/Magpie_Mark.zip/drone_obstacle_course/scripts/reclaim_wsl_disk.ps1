# Run from an elevated Windows PowerShell after Linux cleanup has finished.
# This compacts the existing virtual disk; it never deletes or recreates it.
[CmdletBinding()]
param([switch]$Compact)
$ErrorActionPreference = 'Stop'
$distroName = 'Ubuntu-24.04'
$expectedId = '{9577c85f-a2a2-431a-b697-90cac59b1e46}'
$registration = Get-ItemProperty -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Lxss\$expectedId"
if ($registration.DistributionName -ne $distroName) { throw 'WSL distribution identity changed; refusing to proceed.' }
$vhdName = $registration.VhdFileName
if (-not $vhdName) { $vhdName = 'ext4.vhdx' }
$vhdPath = Join-Path $registration.BasePath $vhdName
if (-not (Test-Path -LiteralPath $vhdPath -PathType Leaf)) { throw "Disk not found: $vhdPath" }
$diskBefore = (Get-Item -LiteralPath $vhdPath).Length
$driveName = [IO.Path]::GetPathRoot($vhdPath).Substring(0,1)
$freeBefore = (Get-PSDrive $driveName).Free
Write-Host "Target: $distroName`nDisk: $vhdPath`nVHD bytes before: $diskBefore`nWindows free bytes before: $freeBefore"
if (-not $Compact) {
    Write-Host 'Inspection only. Run with -Compact to trim, stop this distribution, and compact its disk.'
    return
}
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { throw 'Run Windows PowerShell as Administrator, using the same Windows account.' }
# Copy the worker onto Windows before stopping WSL, so its script and transcript
# remain available after the Linux filesystem disconnects.
$localScript = Join-Path $env:TEMP 'drone-reclaim-wsl-disk.ps1'
if ([IO.Path]::GetFullPath($PSCommandPath) -ne [IO.Path]::GetFullPath($localScript)) {
    Copy-Item -LiteralPath $PSCommandPath -Destination $localScript -Force
    & $localScript -Compact
    return
}
Set-Location -LiteralPath $env:TEMP
$logPath = Join-Path $env:TEMP ('drone-wsl-compaction-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')
Start-Transcript -Path $logPath
try {
    & wsl.exe -d $distroName -u root -- fstrim -v /
    if ($LASTEXITCODE -ne 0) { throw 'Filesystem trim failed; no shutdown or compaction performed.' }
    Write-Host "Stopping $distroName; programs in that distribution will close."
    & wsl.exe --terminate $distroName
    if ($LASTEXITCODE -ne 0) { throw 'WSL termination failed; refusing compaction.' }
    Start-Sleep -Seconds 5
    $diskpartInput = Join-Path $env:TEMP ('drone-wsl-diskpart-' + [guid]::NewGuid().ToString() + '.txt')
    @("select vdisk file=`"$vhdPath`"", 'compact vdisk', 'exit') | Set-Content -LiteralPath $diskpartInput -Encoding ASCII
    # Only select/compact/exit: no partition, format, delete, or resize commands.
    & diskpart.exe /s $diskpartInput
    if ($LASTEXITCODE -ne 0) { throw 'Diskpart reported failure; inspect transcript.' }
    $diskAfter = (Get-Item -LiteralPath $vhdPath).Length
    $freeAfter = (Get-PSDrive $driveName).Free
    Write-Host "VHD bytes after: $diskAfter`nWindows free bytes after: $freeAfter"
    Write-Host "VHD reduction in bytes: $($diskBefore - $diskAfter)"
    if ($diskAfter -ge $diskBefore) { Write-Warning 'Disk file did not shrink. Check diskpart output for errors; no recovery is claimed.' }
    Write-Host 'Compaction attempt finished. Restart Ubuntu-24.04 when ready.'
}
finally {
    Stop-Transcript
    Write-Host "Transcript: $logPath"
}
