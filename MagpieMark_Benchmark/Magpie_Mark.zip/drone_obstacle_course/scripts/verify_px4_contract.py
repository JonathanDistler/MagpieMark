#!/usr/bin/env python3
"""Read-only comparison of integration message fields against a PX4 checkout."""
import argparse
from pathlib import Path

NAMES = ('VehicleOdometry', 'VehicleLocalPosition', 'VehicleCommand',
         'OffboardControlMode', 'TrajectorySetpoint', 'VehicleStatus', 'EstimatorStatusFlags')


def fields(path):
    return [' '.join(value.split()) for line in path.read_text().splitlines()
            if (value := line.split('#', 1)[0].strip())]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--px4-dir', type=Path, default=Path.home() / 'PX4-Autopilot')
    parser.add_argument('--messages', type=Path, default=Path(__file__).resolve().parents[1] / 'px4_msgs/msg')
    args = parser.parse_args()
    failures = []
    for name in NAMES:
        candidates = list((args.px4_dir / 'msg').rglob(name + '.msg'))
        if len(candidates) != 1 or fields(candidates[0]) != fields(args.messages / (name + '.msg')):
            failures.append(name)
        else:
            print(f'MATCH {name}: fields, dimensions, constants, and ordering')
    yaml = (args.px4_dir / 'src/modules/uxrce_dds_client/dds_topics.yaml').read_text()
    for topic in ('/fmu/in/vehicle_visual_odometry', '/fmu/out/vehicle_local_position',
                  '/fmu/out/vehicle_odometry', '/fmu/in/vehicle_command',
                  '/fmu/in/trajectory_setpoint', '/fmu/in/offboard_control_mode',
                  '/fmu/out/estimator_status_flags'):
        if f'topic: {topic}\n' not in yaml:
            failures.append(topic)
    if failures:
        raise SystemExit(f'INCOMPATIBLE or missing: {failures}')
    print('MATCH DDS topic declarations (runtime version suffixes must also be checked)')


if __name__ == '__main__':
    main()
