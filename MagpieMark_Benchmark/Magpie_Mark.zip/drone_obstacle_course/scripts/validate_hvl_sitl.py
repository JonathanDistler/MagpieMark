#!/usr/bin/env python3
"""Unarmed, two-vehicle SITL smoke test. Uses an isolated domain; never issues flight commands.

Source the system ROS overlay first. Existing PX4/Gazebo/agent processes must
be stopped. Keeps small diagnostics, disables bulk recording, and stops owned
processes even when readiness or the read-only fusion check fails.
"""
import argparse
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

PROJECT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('builtin', 'external', 'both'), default='both')
    parser.add_argument('--timeout', type=float, default=120.)
    args = parser.parse_args()
    if not 0 < args.timeout <= 300:
        parser.error('--timeout must be between 0 and 300 seconds')
    env = dict(os.environ, ROS_DOMAIN_ID='92', PYTHONDONTWRITEBYTECODE='1')
    modes = ('builtin', 'external') if args.mode == 'both' else (args.mode,)
    for mode in modes:
        folder = PROJECT / 'results' / 'hvl_smoke' / mode
        folder.mkdir(parents=True, exist_ok=True)
        log_path = folder / 'launcher.log'
        command = ['/usr/bin/python3', str(PROJECT/'scripts/start_simulation.py'),
                   '--ros', 'system', '--n', '2', '--world', 'blank', '--headless',
                   '--skip-build', '--odometry-source', mode, '--run-dir', str(folder)]
        if mode == 'external':
            command += ['--vehicle-config', str(PROJECT/'config/sitl_external.json')]
        print(f'Starting {mode}: {log_path}', flush=True)
        with log_path.open('w') as log:
            process = subprocess.Popen(command, cwd=PROJECT, env=env,
                                       stdout=log, stderr=subprocess.STDOUT,
                                       start_new_session=True)
        try:
            deadline = time.monotonic() + args.timeout
            while 'Ready: 2 drones' not in log_path.read_text(errors='replace'):
                if process.poll() is not None:
                    raise RuntimeError(f'{mode} exited: inspect {log_path}')
                if time.monotonic() > deadline:
                    raise TimeoutError(f'{mode} readiness timeout: inspect {folder}')
                time.sleep(.5)
            if mode == 'external':
                check = ['/usr/bin/python3', str(PROJECT/'scripts/check_external_odometry.py'),
                         '--n', '2', '--vehicle-config', str(PROJECT/'config/sitl_external.json')]
                result = subprocess.run(check, cwd=PROJECT, env=env, text=True,
                                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=40)
                (folder/'fusion-check.txt').write_text(result.stdout)
                print(result.stdout, end='', flush=True)
                result.check_returncode()
            # Verify that even startup has not created bulk flight recordings.
            if any(folder.rglob('*.ulg')) or any(folder.rglob('*.tlog')):
                raise RuntimeError('Unexpected bulk recording in low-disk mode')
            print(f'PASS {mode}: two valid estimators and controller interfaces; no arming or takeoff', flush=True)
        finally:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGINT)
                try:
                    process.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()


if __name__ == '__main__':
    main()
