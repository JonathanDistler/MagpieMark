# Magpie Mark simulation release

The supported launcher starts PX4 SITL, Gazebo Harmonic, a Micro XRCE-DDS
Agent, MAVProxy and the ROS 2 Jazzy control overlay. The release ZIP contains
project sources and reference assets. Ubuntu packages, firmware builds and
Python environments are installed separately.

## Set up a clean Ubuntu 24.04 or WSL2 environment

Extract into a new directory on the Linux filesystem. Use a clean Bash
terminal with Conda deactivated. For the Gazebo window on WSL2, use WSLg
with a working graphics display. A machine without a display can run the
tests with `--headless`. Video in headless mode still needs working EGL
rendering.

```bash
mkdir -p ~/magpie-release
unzip /mnt/c/Users/jonat/Downloads/Magpie_Mark.zip -d ~/magpie-release
cd ~/magpie-release
```

On native Ubuntu, substitute the path where you downloaded the ZIP. Use the
actual candidate filename when evaluating an unreleased build. To verify an
accompanying checksum, run `sha256sum -c Magpie_Mark.zip.sha256` next to the
archive. From the extracted root, run
`sha256sum -c /absolute/path/to/Magpie_Mark.manifest.sha256` to check the
individual files.

Configure the official ROS 2 Jazzy and Gazebo Harmonic apt repositories using
the linked instructions, then install their runtime and development packages.
[ROS 2 Jazzy](https://docs.ros.org/en/jazzy/Installation/Ubuntu-Install-Debs.html)
[Gazebo Harmonic](https://gazebosim.org/docs/harmonic/install_ubuntu/)

```bash
sudo apt update
sudo apt install ros-jazzy-ros-base ros-jazzy-geometry-msgs ros-jazzy-nav-msgs \
  ros-jazzy-std-msgs ros-jazzy-std-srvs ros-jazzy-rcl-interfaces \
  ros-jazzy-rosidl-default-generators ros-jazzy-rosidl-default-runtime \
  python3-colcon-common-extensions python3-venv python3-pip python3-numpy \
  python3-tk build-essential cmake git unzip gz-harmonic \
  python3-gz-msgs10 python3-gz-transport13 python3-opencv
```

Build PX4 and the DDS agent in separate directories. These commands assume
those destination directories do not already exist. PX4's Ubuntu setup
script may request a restart before building.

```bash
git clone https://github.com/PX4/PX4-Autopilot.git ~/PX4-Autopilot
git -C ~/PX4-Autopilot checkout d6f12ad1c4f70ad3230afd7d86e971421e02fef4
git -C ~/PX4-Autopilot submodule update --init --recursive
(cd ~/PX4-Autopilot && bash Tools/setup/ubuntu.sh)
make -C ~/PX4-Autopilot px4_sitl_default

git clone https://github.com/eProsima/Micro-XRCE-DDS-Agent.git ~/Micro-XRCE-DDS-Agent
git -C ~/Micro-XRCE-DDS-Agent checkout 73622810d984349b80bbac0ef55fc0b694d62222
cmake -S ~/Micro-XRCE-DDS-Agent -B ~/Micro-XRCE-DDS-Agent/build -DCMAKE_BUILD_TYPE=Release
cmake --build ~/Micro-XRCE-DDS-Agent/build --parallel 2
sudo cmake --install ~/Micro-XRCE-DDS-Agent/build
sudo ldconfig
command -v MicroXRCEAgent

cd ~/magpie-release
bash scripts/setup_sim.sh
bash scripts/validate_release.sh
```

The launcher accepts `--px4-dir /path/to/PX4-Autopilot` and
`--mavproxy-bin /path/to/mavproxy.py`. Its default startup builds the active
ROS packages. Use `--skip-build` after a successful build. The validation script
builds the two active packages and the preserved legacy ROS controller, checks
the vendored PX4 message contract, and runs the ROS/Python tests. Those tests
are separate from the flight checks below. Stop other SITL sessions before
starting a test and use the same `ROS_DOMAIN_ID` in all terminals for one
session. Use unique `--run-dir` paths to preserve prior logs.

## Dependency versions

The validation host is Ubuntu 24.04.3 LTS on WSL2 with Python 3.12.3, Gazebo
Harmonic/gz-sim 8.11.0, ROS 2 Jazzy (ros-base 0.11.0, rclpy 7.1.5), PX4 commit
`d6f12ad1c4f70ad3230afd7d86e971421e02fef4`, and Micro XRCE-DDS Agent v2.4.3
at `73622810d984349b80bbac0ef55fc0b694d62222`. The project vendors the
`px4_msgs` 2.0.1 sources. The exact files are in the release manifest and the
contract checker compares their fields to the selected PX4 source. Python
additions are pinned in `requirements-venv.txt`, including MAVProxy 1.8.74,
pymavlink 2.4.49 and pytest 8.4.2. MAVSDK 3.17.2 was observed in the original
project venv and is optional for historical direct MAVSDK scripts. The older
Conda snapshot pins MAVSDK 3.15.3.

See [exact Ubuntu package revisions](environment-locks/simulation-ubuntu-noble-packages.tsv),
[observed native versions](environment-locks/simulation-versions.txt),
[agent build records](environment-locks/README.md), and
[optional RoboStack setup](docs/miniconda_setup.md). Apt revisions can roll
forward within those distributions. The clean source build and live checks
reuse installed native tools on the validation host. Installation from scratch
in a second operating system image is **NOT VERIFIED**.

## Run and verify the active simulations

Start the launcher in one terminal. Wait for the exact `Ready:` message before
running another command, except for automatic tests, which start their own
flight. In a second terminal at the extracted root use:

```bash
source /opt/ros/jazzy/setup.bash
source install-system/local_setup.bash
```

| Behavior | Launcher and client commands | Verification criteria |
| --- | --- | --- |
| Single UAV, blank world | `bash scripts/run_sim.sh --n 1 --world blank`. Then `/usr/bin/python3 scripts/swarm_validity_test.py --n 1 --fly` | GCS heartbeat and valid PX4 estimator, live ROS interfaces, explicit arm and 2 m takeoff, six measured 0.5 m moves, hold, touchdown and disarm |
| Single UAV interactive | Same launch. Then use `ros2 run swarm_mavsdk_ros2 control_console --drone 0` | Use `startup`, `arm`, `takeoff`, `forward 0.5`, `right 0.5 velocity 0.4`, `stop`, `land`, then `disarm` after touchdown. State uses local NED in metres. The one-shot equivalents use `drone_command`. |
| Static obstacle trajectories | `bash scripts/run_sim.sh --n 1 --world obstacles --tests 1 2 3`. Or omit `--tests` and call `ros2 run swarm_mavsdk_ros2 drone_command test 1 --drone 0` through `test 3` separately | Alternating cone offsets, flag left/right path, and box course. Completion and time-series CSV under `results/tests`. Tests use known geometry and a simulated flag signal. Position and velocity modes exist. Automatic mode records one session MP4. |
| Three simultaneous UAVs | `bash scripts/run_sim.sh --n 3 --world swarm`. Then `/usr/bin/python3 scripts/validate_flight_controls.py --n 3 --controls-only` | Three valid estimators, distinct MAV system IDs/DDS routes, position and velocity checks, synchronized departure and measured landing/disarm. Default routes are unprefixed, `/px4_1`, `/px4_2`. Logical clients remain `/drone_0` through `/drone_2`. |
| Central fleet commands and formation | Same launch. In the second terminal run `swarm_command startup`, `arm`, `takeoff`, then formation or movement commands below | Measured separation and settled targets. Supported shapes are line/grid/circle, plus randomization, split, translation and yaw. The controller stages crossing paths around other drones. |
| Edge-controlled swarm | Add `--architecture edge:drone_0` to launch and `/usr/bin/python3 scripts/validate_flight_controls.py --n 3 --architecture edge:drone_0 --controls-only` | Drone 0 dispatches shared commands to all members, including itself. This is a command-routing role. Autonomous pursuit of a moving leader is not implemented. |
| Three swarm benchmarks | Same central or edge swarm launch. Then use `/usr/bin/python3 scripts/validate_flight_controls.py --n 3` with matching architecture | Test 1 measures translation MSE, test 2 random-to-line time and target RMSE, test 3 partition translation MSE. Validator runs position and velocity variants where the session remains healthy. Per-flight CSV and summaries are under `results/control_validation`. |
| Recorded three-drone circles | `bash scripts/run_sim.sh --n 3 --circle-test` | All reach 2 m, drones 0 and 2 orbit at radius 1.35 m, drone 1 descends through the first center and ascends through the second. Wait for `Drone 1 completed pass 1` in `results/startup/circle-test.log`. Type `q` + Enter. Verify three landings/disarms and one playable `flight-*.mp4`. |
| Staggered counter-rotating circles | `bash scripts/run_sim.sh --n 3 --staggered-circles` | Viewed from above, cyan drone 0 orbits counterclockwise and amber drone 2 clockwise over the grey 1 m grid. The centers are staggered 1.3 m East–West. Magenta drone 1 descends through the first center and ascends through the second. After `completed pass 1`, enter `q` in the launcher and check the MP4 for all three numbered trails. |
| Simulated external odometry | `bash scripts/run_sim.sh --n 3 --world blank --odometry-source external`. Then `/usr/bin/python3 scripts/check_external_odometry.py --n 3` | Gazebo world pose → PoseStamped → converted PX4 VehicleOdometry pose, fresh input and estimator fusion independently on all three DDS routes. No hardware required. |
| Two-vehicle custom external routing | `/usr/bin/python3 scripts/validate_hvl_sitl.py --mode external` after building/sourcing | Isolated domain 92, mapped `/uav_0` and `/uav_1`, read-only fusion and no arming. Existing two-vehicle SITL and bench examples remain separate from the three-vehicle HVL example. |
| Mock tracker and Vicon adapter | `ros2 launch swarm_mavsdk_ros2 odometry.launch.py num_drones:=3 vehicle_config:="$PWD/config/hvl_external.example.json"` with the matching mock tracker shown below | Three pose streams, routed timestamped VehicleOdometry, stale/invalid message rejection. Physical acquisition and measured calibration remain unvalidated. |
| Video, topic recording, and dashboard | Video runs by default. Add `--record` for bulk telemetry or `--dashboard` for the live display. | One MP4 with drone IDs and measured flight trails under `--run-dir` from startup to launcher exit. Drone 0 is cyan, drone 1 magenta, and drone 2 amber. Optional ROS telemetry goes under `results/ros2`. |
| Policy and RL interfaces | Run in an already started SITL session as described in [portable policies](docs/telemetry_and_policies.md) and [controls](docs/flight_controls.md) | Standard observation, normalized NED actions, bounded velocity and stale-data behavior. Synthetic/mock coverage is separate from live policy flight. |

For representative formation calls, after takeoff:

```bash
ros2 run swarm_mavsdk_ros2 swarm_command formation --n 3 --shape line --spacing 1.5
ros2 run swarm_mavsdk_ros2 swarm_command formation --n 3 --shape grid --spacing 2
ros2 run swarm_mavsdk_ros2 swarm_command formation --n 3 --shape circle --spacing 2
ros2 run swarm_mavsdk_ros2 swarm_command randomize 3 --n 3 --seed 42
ros2 run swarm_mavsdk_ros2 swarm_command split --n 3 --direction left
ros2 run swarm_mavsdk_ros2 swarm_command translate --n 3 --ned 0 1 0
ros2 run swarm_mavsdk_ros2 swarm_command yaw_by --n 3 --radians 0.25
ros2 run swarm_mavsdk_ros2 swarm_command stop --n 3
ros2 run swarm_mavsdk_ros2 swarm_command land --n 3
# Confirm touchdown before disarming.
ros2 run swarm_mavsdk_ros2 swarm_command disarm --n 3
```

One-shot fleet examples use `ros2 run swarm_mavsdk_ros2 swarm_command startup --n 3`
and the same form with `arm`, then `takeoff`. To run one benchmark, call
`ros2 run swarm_mavsdk_ros2 swarm_command test 1 --n 3 --seed 42`, substituting
the test number and adding `--mode velocity --speed 0.4` as needed. The
six-case central validation used
`bash scripts/run_sim.sh --headless --n 3 --world swarm --spacing 1.5`
and dispatched each test independently with seed 42 and speed 0.4 m/s.
Bulk recording was disabled for that run. See the companion release report
for the separate run with the bulk recorder enabled.
Historical SITL results in the documentation refer to earlier source snapshots.

## Assets, interfaces and boundaries

For an isolated, three-vehicle mock odometry check with no PX4 running, source
the overlay in both terminals and use the same unused ROS domain:

```bash
export ROS_DOMAIN_ID=93
ros2 launch swarm_mavsdk_ros2 odometry.launch.py num_drones:=3 vehicle_config:="$PWD/config/hvl_external.example.json"
```

```bash
export ROS_DOMAIN_ID=93
ros2 run swarm_mavsdk_ros2 mock_tracker --ros-args -p num_drones:=3 \
  -p vehicle_config:="$PWD/config/hvl_external.example.json" -p axis:=x -p dropout_after_s:=15.0
```

Within the first 15 seconds, observe `/fmu/in/vehicle_visual_odometry` and
the same topic under `/px4_1` and `/px4_2`. Updates should stop after
the mock input drops out. A synthetic feed does not establish real Vicon
timing, frame calibration or PX4 fusion on an aircraft.

- `worlds/blank.sdf` is the open takeoff/circle arena with a grey 1 m grid. `drone_obstacle_course.sdf`
  references the cone/flag and box SDF models, their meshes, and three start
  markers. `drone_obstacle_course_swarm.sdf` is the dedicated gridded benchmark arena.
  The external PX4 Gazebo models provide x500 and x500_vision. The camera is
  added to the selected world at launch for video. The blank and swarm worlds
  share the `models/flight_grid` model and its mesh. The camera records from
  before PX4 startup through launcher exit, including manual flights and
  benchmarks. The numbered trails are drawn from Gazebo model poses in the
  saved MP4. Enter `q` or `quit` in the launcher terminal, or press Ctrl+C,
  to finalize a run. Use `--no-video` for an unrecorded session.
- The active controller uses ROS messages and PX4 uXRCE-DDS for commands and
  telemetry. MAVProxy provides the native MAVLink GCS connection and optional
  .tlog files. The `swarm_mavsdk_ros2` package name also covers the ROS-only
  control implementation. Its two launch files are `swarm.launch.py` and
  `odometry.launch.py`. The first starts the drone interfaces, central or edge
  control and optional topic recording. The second starts the external adapter
  and can start the Gazebo pose publisher.
- Public ROS executables include `drone_node`, `drone_command`, `control_console`,
  `swarm_controller`, `swarm_command`, `swarm_tests`, `topic_recorder`,
  `telemetry_dashboard`, `external_odometry`, `gazebo_tracker`, and
  `mock_tracker`. Use `--show-args` on either ROS launch command for parameters.
  SITL offboard controls use explicit startup, pre-stream warm-up, explicit
  arm and takeoff, a settled takeoff barrier, and stop/land/disarm services.
  Per-test tracking/telemetry timeouts and the fleet separation checks cover
  some faults. Loss of a policy client alone can leave a last command streaming.
- Obstacle maneuvers follow predefined course geometry. The release does not
  provide perception, camera flag recognition, generic obstacle avoidance or
  arbitrary-world planning. Formation separation checks are not a guarantee
  of physical collision avoidance.
- The three-vehicle `config/hvl_external.example.json`, the
  [Vicon adapter contract](docs/vicon_adapter_contract.md), the
  [HVL recovery report](docs/hvl_recovery_validation.md) and
  `scripts/validate_hvl_sitl.py` are carried forward. The archive also contains
  the hardware guide, ROS odometry nodes and launch, converters, mock tracker,
  fusion checker, test cases and all three example mapping files. The sample
  three-drone DDS keys and system IDs are 1/2/3. Body names and frame/marker
  calibration values are examples. The teammate-owned acquisition adapter and
  a real Vicon driver are external. Hardware acquisition, calibration,
  aircraft flight, and failsafe performance are **NOT VERIFIED**.
- The ZIP preserves `run_drone_swarm.bash`, the older shell launchers, direct
  MAVSDK scripts, the standalone `drone_swarm_controller` ROS package, and
  superseded implementation snapshots. These are historical alternatives
  with their own assumptions and are **NOT VERIFIED** for this release.
  Use the active launcher above for the supported simulation workflows.
  Existing optional Conda and Jetson instructions remain in the repository.
- The empty-manifest `ros2/swarm_mavlink_ros2` has no dependency, active
  import, launch reference or entry point in the supported workflow. It is
  excluded from the ZIP. The original local directory is retained.

## Troubleshooting

- If PX4 or DDS readiness times out, inspect `gazebo.log`, `px4-N.log`,
  `mavproxy-N.log`, `readiness.log` and `interfaces.log` in the run directory.
  Confirm all wrappers use the same ROS domain, the expected PX4 commit and
  the same drone count. Do not share port 8888 or PX4 instance sockets
  between concurrent runs.
- If a GUI or camera fails to initialize, check the WSLg display and GL/EGL
  support. Try `gz sim --versions` and the nonrecorded blank-world launch for
  isolation. Use `--headless --no-video` to run without the camera renderer.
- Inspect `circle-test.log` or the per-run test CSVs for a movement stall,
  telemetry gap, or loss of armed OFFBOARD status. Headless and software
  rendering can advance simulation slower than wall clock. Use the reported
  test completion rather than a fixed wall-clock delay.
- For manual flows, send `land`, confirm touchdown, then send `disarm`
  before stopping the launcher. The recorded circle command handles landing
  on `q`. SITL launch parameters apply to simulated aircraft only.

## Historical entry points

These are included for source continuity. The live release checks use the
current launcher and ROS control package described above.

| Entry point | Original purpose and invocation |
| --- | --- |
| `scripts/start_single_drone_ros2.sh` | `bash scripts/start_single_drone_ros2.sh blank` or `test`. This forwards to the shared launcher with the blank or obstacle world. |
| `scripts/start_swarm_ros2.sh` | `bash scripts/start_swarm_ros2.sh --n 3`; older built-in-vision SITL lifecycle. |
| `scripts/drone_commands.sh` | Source with `DRONE_WORKSPACE_SETUP="$PWD/install-system/local_setup.bash"` in the environment for its Bash command helpers. |
| `run_drone_swarm.bash` and `ros2/swarm_mavsdk_ros2/run_blank_swarm.bash` | Older swarm and blank-world launchers. See each script's header and its directory and namespace assumptions. |
| `ros2 run drone_swarm_controller drone_test_swarms --n 3 --seed 42` | Legacy ROS-based velocity benchmarks. Requires independently prepared `/uav_0`, `/uav_1`, `/uav_2` routes. See its package README. |
| `drone_tests.py 1`, `2`, or `3` | Legacy single-drone MAVSDK obstacle controller expecting an existing simulator and its own connection/airborne prerequisites. |
| `drone_test_swarms.py --n 3 --seed 42` and `drone_tests_swarms.py --n 3 --seed 42` | Legacy direct MAVSDK fleet experiments, with configurable `--base-port`. |
| `scripts/drone_test_fixed.py` and `scripts/drone_tests.py` | Standalone legacy MAVSDK waypoint tests. The latter writes its own metrics. |

For legacy Python scripts, the optional dependency can be installed into the
local venv with `.venv/bin/python -m pip install 'mavsdk==3.17.2'`. Call the
scripts with `.venv/bin/python`. Their connection addresses and assumptions
are separate from the supported ROS/DDS tests.
