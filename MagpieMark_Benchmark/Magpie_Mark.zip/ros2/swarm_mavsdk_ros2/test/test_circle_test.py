from itertools import combinations
from math import dist, hypot

import pytest

from swarm_mavsdk_ros2.circle_test import (
    HEIGHT, ORBIT_LEAD_IN, RADIUS, VERTICAL_CLEARANCE, circle_targets,
)


def test_transit_crosses_the_two_circle_centers_in_opposite_directions():
    centers = (0., 4.)
    crossing = ORBIT_LEAD_IN + VERTICAL_CLEARANCE
    other_crossing = crossing + 2 * VERTICAL_CLEARANCE + 4.
    for phase, center, direction in [(crossing, 0., 1), (other_crossing, 4., -1)]:
        assert circle_targets(phase, centers)[1] == pytest.approx((center, 0., -HEIGHT))
        assert circle_targets(phase - .1, centers)[1][2] == pytest.approx(-HEIGHT - .1 * direction)
        assert circle_targets(phase + .1, centers)[1][2] == pytest.approx(-HEIGHT + .1 * direction)


def test_orbits_hold_radius_altitude_and_clearance_over_repeated_passes():
    centers = (0., 4.)
    for sample in range(4000):
        points = circle_targets(sample / 100, centers)
        for index, center in zip((0, 2), centers):
            n, e, d = points[index]
            assert hypot(n - center, e) == pytest.approx(RADIUS)
            assert d == -HEIGHT
        assert min(dist(a, b) for a, b in combinations(points, 2)) >= 1.19
