from itertools import combinations
from math import dist, hypot, pi

import pytest

from swarm_mavsdk_ros2.circle_test import (
    EAST_STAGGER, HEIGHT, ORBIT_LEAD_IN, RADIUS, VERTICAL_CLEARANCE, circle_targets,
)


def test_transit_crosses_the_two_circle_centers_in_opposite_directions():
    centers = (0., 4.)
    crossing = ORBIT_LEAD_IN + VERTICAL_CLEARANCE
    other_crossing = crossing + 2 * VERTICAL_CLEARANCE + 4.
    for phase, center, direction in [(crossing, 0., 1), (other_crossing, 4., -1)]:
        assert circle_targets(phase, centers)[1] == pytest.approx((center, 0., -HEIGHT))
        assert circle_targets(phase - .1, centers)[1][2] == pytest.approx(-HEIGHT - .1 * direction)
        assert circle_targets(phase + .1, centers)[1][2] == pytest.approx(-HEIGHT + .1 * direction)


def test_orbits_hold_radius_altitude_and_clearance_over_repeated_passes():
    centers = (0., 4.)
    for sample in range(4000):
        points = circle_targets(sample / 100, centers)
        for index, center in zip((0, 2), centers):
            n, e, d = points[index]
            assert hypot(n - center, e) == pytest.approx(RADIUS)
            assert d == -HEIGHT
        assert min(dist(a, b) for a, b in combinations(points, 2)) >= 1.19


def test_staggered_orbits_counter_rotate_and_transit_through_both_centers():
    centers = (0., 4.)
    start = circle_targets(0., centers, staggered=True)
    quarter = circle_targets(pi * RADIUS / 2, centers, staggered=True)
    assert start[0] == pytest.approx((0., RADIUS - EAST_STAGGER, -HEIGHT))
    assert start[2] == pytest.approx((4., RADIUS + EAST_STAGGER, -HEIGHT))
    assert quarter[0] == pytest.approx((RADIUS, -EAST_STAGGER, -HEIGHT))
    assert quarter[2] == pytest.approx((4. - RADIUS, EAST_STAGGER, -HEIGHT))
    first = ORBIT_LEAD_IN + VERTICAL_CLEARANCE
    second = first + 2 * VERTICAL_CLEARANCE + hypot(4., 2 * EAST_STAGGER)
    assert circle_targets(first, centers, staggered=True)[1] == pytest.approx(
        (0., -EAST_STAGGER, -HEIGHT))
    assert circle_targets(second, centers, staggered=True)[1] == pytest.approx(
        (4., EAST_STAGGER, -HEIGHT))
    for sample in range(4000):
        points = circle_targets(sample / 100, centers, staggered=True)
        assert min(dist(a, b) for a, b in combinations(points, 2)) >= 1.19
