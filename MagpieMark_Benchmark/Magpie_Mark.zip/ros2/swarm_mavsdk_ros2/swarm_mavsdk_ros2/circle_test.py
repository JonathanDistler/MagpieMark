"""Central three-drone flight in the empty Gazebo world."""

import math
import select
import sys
import time

import rclpy

from .obstacle_tests import launch_configuration
from .spinning import spin_for
from .swarm_behaviors import validate_points


RADIUS = 1.35
HEIGHT = 2.0
VERTICAL_CLEARANCE = 1.2
MIN_SEPARATION = 0.85
SPEED = 0.45
TICK = 0.05
ORBIT_LEAD_IN = math.pi * RADIUS / 2


class QuitRequested(Exception):
    pass


def check_quit():
    # A terminal submits q/quit on Enter. EOF also stops a piped session.
    if select.select([sys.stdin], [], [], 0)[0]:
        line = sys.stdin.readline()
        if not line or line.strip().lower() in {"q", "quit"}:
            raise QuitRequested


def circle_targets(phase, centers):
    """Sample synchronized orbits and a closed path through their centers."""
    left, right = centers
    down = -HEIGHT
    above, below = down - VERTICAL_CLEARANCE, down + VERTICAL_CLEARANCE
    loop = [(left, 0., above), (left, 0., below),
            (right, 0., below), (right, 0., above), (left, 0., above)]
    remaining = max(0., phase - ORBIT_LEAD_IN) % (4 * VERTICAL_CLEARANCE + 2 * (right - left))
    for start, end in zip(loop, loop[1:]):
        length = math.dist(start, end)
        if remaining <= length:
            transit = tuple(a + (b - a) * (remaining / length) for a, b in zip(start, end))
            break
        remaining -= length

    angle = phase / RADIUS
    north, east = RADIUS * math.sin(angle), RADIUS * math.cos(angle)
    return [(left + north, east, down), transit, (right + north, east, down)]


def land_fleet(controller):
    controller.land_all()
    deadline = time.monotonic() + 150.
    while any(drone.armed is not False for drone in controller.drones):
        if time.monotonic() >= deadline:
            raise TimeoutError("Timed out waiting for PX4 to disarm after landing.")
        spin_for(controller)


def run_circle_test(controller):
    if controller.drone_count != 3:
        raise ValueError("The circle test requires exactly drones 0, 1, and 2.")
    configs = [launch_configuration(drone) for drone in controller.drones]
    if any(world != "blank" for world, _ in configs):
        raise RuntimeError("The circle test requires the blank Gazebo world.")
    left, middle, right = (north for _, north in configs)
    if min(middle - left, right - middle) < 2.0:
        raise ValueError("The circle test requires at least 2 m spawn spacing.")
    if any(not math.isclose(drone.takeoff_target_down(), -HEIGHT) for drone in controller.drones):
        raise ValueError("The circle test requires a 2 m takeoff height.")

    behaviors = controller.behaviors()
    centers = left, right
    flight_started = False
    rims_staged = False
    try:
        check_quit()
        controller.startup_all()
        check_quit()
        flight_started = True
        controller.arm_all()
        check_quit()
        controller.takeoff_all(timeout_s=150., check_cancel=check_quit)

        def check_setup(_phase, _targets, _points):
            check_quit()

        check_quit()
        start = circle_targets(0., centers)
        behaviors.move_to([start[0], (middle, 0., -HEIGHT - VERTICAL_CLEARANCE), start[2]],
                          sample=check_setup, phase="circle staging", separation=MIN_SEPARATION)
        rims_staged = True
        behaviors.move_to(start, sample=check_setup, phase="circle entry", separation=MIN_SEPARATION)

        print("Flying circles. Type q or quit and press Enter to land.", flush=True)
        phase = 0.
        loop_length = 4 * VERTICAL_CLEARANCE + 2 * (right - left)
        next_lap = ORBIT_LEAD_IN + loop_length
        laps = 0
        progressed = time.monotonic()
        while rclpy.ok():
            check_quit()
            try:
                actual = behaviors.positions(timeout_s=1)
            except TimeoutError:
                controller.command_all("stop")
                check_quit()
                actual = behaviors.positions(timeout_s=5)
                progressed = time.monotonic()
            validate_points(actual, 3, MIN_SEPARATION)
            targets = circle_targets(phase, centers)
            if max(math.dist(point, target) for point, target in zip(actual, targets)) <= .24:
                phase += SPEED * TICK
                progressed = time.monotonic()
                targets = circle_targets(phase, centers)
                if phase >= next_lap:
                    laps += 1
                    next_lap += loop_length
                    print(f"Drone 1 completed pass {laps} through both circles.", flush=True)
            if time.monotonic() - progressed > 10:
                raise TimeoutError("Circle flight stalled while tracking its targets.")
            for drone, target in zip(controller.drones, targets):
                drone.move_to(*target)
            spin_for(controller, TICK)
    except QuitRequested:
        print("Circle test stopped. Landing the fleet.", flush=True)
        if rims_staged:
            # Place drone 1 over a circle center before landing, so descent
            # cannot take it through a stopped drone on the rim.
            controller.command_all("stop")
            points = behaviors.positions()
            north, _, down = points[1]
            center = min(centers, key=lambda value: abs(value - north))
            points[1] = (center, 0., down)
            behaviors.move_to(points, phase="landing approach", separation=MIN_SEPARATION)
    finally:
        if flight_started and rclpy.ok():
            land_fleet(controller)
